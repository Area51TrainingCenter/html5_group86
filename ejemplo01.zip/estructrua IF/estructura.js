
var user="jc";
var usuario=prompt("ingresa usuario");
var pass=prompt("ingresa password");

// usuario== admin
// pass ==1234

/*
if(usuario=="admin")
{
	if(pass="1234"){
		console.log("el usuario y el password son correctos")
	}
	else{
		console.log("verificar datos ingresados");
		}
}
else
{
		console.log("verificar datos ingresados");
}
*/

if(usuario=="admin" && pass="1234"){
console.log("los datos ingresados fueron correctos")
}
else{
console.log("verificar los datos ingresados");
}





console.log("termino el programa")
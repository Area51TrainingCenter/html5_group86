 //var elemento=$(".btn-cambiar-titulo");
 $(".btn-verde").click(tarea)
 function tarea(){
	//$("#titulo-site").html("Titulo modificado")
 	$("#titulo-site").removeClass("rojo")
 	$("#titulo-site").addClass("verde");
 }

 $(".btn-rojo").click(tarearojo)
 function tarearojo(){
	$("#titulo-site").removeClass("verde");
	$("#titulo-site").addClass("rojo");	
	//$("#titulo-site").html("Titulo modificado")
 }
 //$("selector de elemento ").evento()}



$(".agregar-body").click(color)
function color(){
	$("body").addClass("color1")
}


$(".quitar-body").click(colorquitar)
function colorquitar(){
	$("body").removeClass("color1")
}







$(".quitar-body").click(function (){
	$("body").removeClass("color1")
})




$("#datos").click(traerDatos)
function traerDatos(){
	var nombre=$("#nombre").val();
     $("#titulo-site").html("Bievenido : "+nombre);
}







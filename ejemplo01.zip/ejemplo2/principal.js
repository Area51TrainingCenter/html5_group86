alert("Bienvenido al Curso de JS")
/*var nombre;
var apellido;
nombre=prompt("Ingresa tu nombre");
apellido=prompt("Ingresa tu apellido");

console.log(nombre);
console.log(apellido);
*/
// ingrese 2 numero 
// 4 operaciones
// resultado de las 4 operaciones

var numero1=prompt("ingresa numero1");
var numero2=prompt("ingresa numero2");

var suma=parseInt(numero1)+parseInt(numero2);
console.log(suma);

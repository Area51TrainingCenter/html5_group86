console.log("JS funciona!!");

/** como definir una variable **/

var nombre;
var apellidos;
var dato1;
var dato2;
var numero1;
var numero2;


//console.log(nombre)
//console.log(apellidos)

nombre = "Juan Carlos";
apellidos="Ramos Torriccelli";
dato1="1991";

var nombreCompleto=nombre + " " + apellidos;
console.log(nombreCompleto);
dato2=1990;
numero1=10;
numero2=30;


console.log(nombre)
console.log(apellidos)
console.log(dato1)
console.log(dato2)
console.log(numero1)
console.log(numero2)



var num1=10;
var num2=20;
var suma=num1%num2;
console.log(suma);

var valorDePi=Math.PI;
console.log(valorDePi);
var maximo=Math.max(19,20,30,04,55,90);
console.log("el numero maximo es :",maximo);
var minimo=Math.min(19,20,30,04,55,90);
console.log("el numero minimo es :",minimo);

//var aleatorio=Math.random();
//console.log(aleatorio);

var decimal=9.939432;
var sindecimal=Math.round(decimal);
console.log(sindecimal);


var aleatorio=Math.random()*100;
console.log("numero aleatorio :",aleatorio);
var entero=parseInt(aleatorio);
console.log(entero);



var numero4="50";
var numero5="20";

var parsenumer4=parseInt(numero4);
var parsenumer5=parseInt(numero5);

var suma2 = parsenumer4+parsenumer5;

console.log(suma2)













/* variables bool */

var estado=false;


/* variable de tipo  fecha */

var fechaTexto="25/02/2017";
var fecha=new Date();
console.log(fecha);
/*
console.log("el mes es: ",fecha.getMonth())
console.log("el año es",fecha.getFullYear())
console.log("el día es ",fecha.getDate())
console.log("el dia de la semana es ",fecha.getDay())
console.log("la hora es :" , fecha.getHours())
console.log("los minutos son :" , fecha.getMinutes())
console.log("la segundos son:" , fecha.getSeconds())
*/

var nomber1="juanc";
var nombre2="barbara";
var nombre3="Diego";
var nombre4="Luis";
var fecha2=new Date();
var dias=["lunes","martes"];
var listaAlumnos=[
					"luis",
					20,
					fecha,
					"texto",
					dias
					];

console.log(listaAlumnos[4][0])
console.log(listaAlumnos[4][1])
	/*				
console.log("la cantidad de elementos del arreglo es: "+listaAlumnos.length);
console.log(listaAlumnos[0]);
var limite=listaAlumnos.length-1;
console.log(listaAlumnos[limite]);*/

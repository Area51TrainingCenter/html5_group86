var elemento1;
elemento1=document.getElementById('parrafo1');
elemento1.addEventListener("click",tarea2);


function tarea2(){
	var titulo=document.getElementById('titulo');
	titulo.style="color:red;font-family:arial";
}
var opcion1=document.getElementById('cambiar');

opcion1.addEventListener("click",tarea1)
function tarea1(){
	var titulo=document.getElementById('titulo');
	titulo.innerHTML="Titulo Modificado";
	}
/*var elemento1=document.getElementsByTagName('p')
var elemento1= document.getElementById('parrafo1')
var elemento1=document.getElementsByClassName('textos')
*/


var elemento2=document.getElementById('parrafo2');
elemento2.addEventListener("click",resetear)
function resetear(){
    var titulo=document.getElementById('titulo');
	titulo.innerHTML="";
}
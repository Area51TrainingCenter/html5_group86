
sumar(5,6);
sumar(15,9);
sumar(25,1);
sumar(4,2);

var resultado=sumarretorno(10,10);


imprimir("estoy imprimiendo en consola con mi propia funcion");
// funcion sin parametros sin retorno //
/*function sumar()
{
	var num1=10;
	var num2=20;
	var suma=num1+num2;
	console.log(suma);

}*/
// funcion con parametros sin retorno //
function sumar(valor1,valor2)
{
	
	var suma=valor1+valor2;
	console.log(suma);

}

function imprimir(texto){
	console.log(texto);
}

function sumarretorno(valor1,valor2){

	var suma=valor1+valor2;
	return suma;
}